module com.mycompany.hibernatelab {
    requires javafx.controls;
    requires org.hibernate.orm.core;
    requires java.naming;
    requires java.persistence;
    requires java.sql;
    opens  com.mycompany.hibernatelab to org.hibernate.orm.core;
    exports com.mycompany.hibernatelab;
}
