/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hibernatelab;
import javax.persistence.Column; 
import javax.persistence.Id;
import javax.persistence.Entity;
/**
 *
 * @author nf
 */
@Entity
public class actor implements java.io.Serializable {
    
    
@Id
@Column(name="actor_id")
private int id; 
@Column(name="first_name") 
private String firstName; 
@Column(name="last_name") 
private String lastName;
@Column(name="ast_update") 
private String astupdate;


public actor() {

}



public actor(String fname, String lname) {
this.firstName = fname;
this.lastName = lname; 
}


public int getId() {
return this.id;
}


public void setId(int id) { 
    this.id = id;
}

public String getFirstName() { 
    return firstName;
}

public void setFirstName(String firstName) { 
    this.firstName = firstName;
}

public String getLastName() { 
    return lastName;
}

public void setLastName(String lastName) { 
    this.lastName = lastName;
} 

public String getAstUpdate() { 
    return lastName;
}

public void setAstUpdate(String astupdate) { 
    this.astupdate = astupdate;
} 


}
