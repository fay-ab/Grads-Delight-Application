/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hibernatelab;

import javafx.scene.control.DatePicker;
import javax.persistence.Column; 
import javax.persistence.Id; 
import javax.persistence.Entity; 

 
@Entity 
public class Neworder  implements java.io.Serializable {
    
    
     @Id 
     @Column(name="order_number") 
     private int orderNumber; 
     
     @Column(name="price_n")
     private int totalPrice; 
     
     
     @Column(name="package_t") 
     private String packageType; 
     
   
    @Column(name="date_o") 
     private String date; 
    
    
     ////////////////////////////////how to write the forign key
       


    public Neworder() {
    }

    public Neworder(int orderNumber, int totalPrice, String packageType, String date) {
        this.orderNumber = orderNumber;
        this.totalPrice = totalPrice;
        this.packageType = packageType;
        this.date = date;
    
    }

    public int getOrderNumber() {
        return orderNumber;
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public String getPackageType() {
        return packageType;
    }

    public String getDate() {
        return date;
    }

   

    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public void setDate(String date) {
        this.date = date;
    }

 

    
     
   
    
}
