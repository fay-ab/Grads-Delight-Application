/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hibernatelab;


import javafx.scene.control.DatePicker;
import javax.persistence.Column; 
import javax.persistence.Id; 
import javax.persistence.Entity; 

 
@Entity 
public class Trypro  implements java.io.Serializable {
    
    
     @Id 
     @Column(name="id_t") 
     private int id; 
     
     @Column(name="name_t")
     private String name; 
     
     
     @Column(name="date_t") 
     private String date; 

    public Trypro() {
    }

    public Trypro(int id, String name, String date) {
        this.id = id;
        this.name = name;
        this.date = date;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }
     
     
}
