package com.mycompany.hibernatelab;


import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.Math.random;
import static java.lang.StrictMath.random;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import static javafx.application.Application.STYLESHEET_MODENA;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import org.hibernate.Session; 
import org.hibernate.Transaction; 
import org.hibernate.query.Query;

/**
 * JavaFX App
 */

public class App extends Application {
 //-----------------------------------------
    static int total =0;
    int Pprice;
    String PackageType;
 
     TextField priceDisplay = new TextField();
 
     Neworder order=new Neworder();
     Label PriceLabel= new Label("Total Price is:",priceDisplay);
     public void handleCheckboxAction(CheckBox checkbox, int price) {
        if (checkbox.isSelected()) {
            order.setTotalPrice(order.getTotalPrice() + price);
        } else {
            order.setTotalPrice(order.getTotalPrice() - price);
        }
        total= order.getTotalPrice()+Pprice;
     
       System.out.println("Total is: " + total);
       
       
        priceDisplay.setEditable(false);
        priceDisplay.setMaxWidth(70);
        priceDisplay.setText(String.valueOf(total));

     }   
     
    
    
    @Override
    public void start(Stage stage) {
        
        
        //----------------------START HOME PAGE----------------------
        
        
        Image imagetheam = new Image("file:/Users/nf/Desktop/AP1/HibernateLab/IMG_6846-removebg-preview.png");
        ImageView imageViewtheam = new ImageView(imagetheam);//Setting the image view
        imageViewtheam.setFitWidth(150);
        imageViewtheam.setFitHeight(130);
        
        Text textwelcom = new Text("We make your day special");
        textwelcom.setFont(Font.font("Arial Rounded MT Bold", 20));
        textwelcom.setTextAlignment(TextAlignment.CENTER);
        textwelcom.setFill(Color.DARKGOLDENROD);
        
        Text textdescreption = new Text("graduation day is a big moment and something \nto be remembered forever.We can help with every aspect\n of planning and coordinating a graduation\n party or ceremony, so that everyone is sure to have an\n incredible time.");
        textdescreption.setFont(Font.font("Gabriola", 15));
        textdescreption.setTextAlignment(TextAlignment.CENTER);
        textdescreption.setFill(Color.DARKKHAKI);

        TextArea f = new TextArea("graduation day is a big moment for anyonebig moment/n for anyone. That’s why you want the occasion to be as memorable as possible.Friends, family and fellow students all make such days great fun and something to be remembered forever.We can help with every aspect of planning and coordinating a graduation party or ceremony, so that everyone is sure to have an incredible time.");
        f.wrapTextProperty();
        
        //button
        Button btcart = new Button("My Orders");
        btcart.setStyle("-fx-background-color:#657166");
        btcart.setTextFill(Color.WHITE);

        Button btpackges = new Button("packages");
        btpackges.setStyle("-fx-background-color:#657166");
        btpackges.setTextFill(Color.WHITE);
        //
        HBox foricon = new HBox(40);

        VBox page1 = new VBox(20);
        foricon.getChildren().addAll(btcart,  btpackges);
        foricon.setAlignment(Pos.CENTER);
        page1.setMargin(imageViewtheam, new Insets(10, 0, 0, 105));
        page1.setMargin(textwelcom, new Insets(0, 0, 0, 55));
        page1.setMargin(foricon, new Insets(70, 0, 0, 0));
        page1.setPadding(new Insets(15, 15, 15, 15));
        page1.getChildren().addAll(imageViewtheam, textwelcom, textdescreption, foricon);
        /////
        page1.setStyle("-fx-background-color:#FEFDF1;");
        
        
        //page5
        VBox page5 = new VBox(30);
        page5.setPadding(new Insets(10, 10, 10, 10));

        Label laconfirmed = new Label("your order confirmed");
        HBox hbconfirmed = new HBox(10);
        hbconfirmed.getChildren().add(laconfirmed);
        hbconfirmed.setAlignment(Pos.CENTER);
        Label laserchnumber = new Label("enter your number");
        TextField tfserchnumber = new TextField();
        HBox fornumber = new HBox(10);
        fornumber.getChildren().addAll(laserchnumber, tfserchnumber);

        //
        Label lanameserch = new Label("name");
        TextField tfnameserch = new TextField();
        HBox forname = new HBox(10);
        forname.getChildren().addAll(lanameserch, tfnameserch);

        //
        Label ladateserch = new Label("date of order");
        TextField tfdateserch = new TextField();
        HBox fordate = new HBox(10);
        fordate.getChildren().addAll(ladateserch, tfdateserch);
        //
        Label lapackageserch = new Label("package type");
        TextField tfpackageserch = new TextField();
        HBox forpackage = new HBox(10);
        forpackage.getChildren().addAll(lapackageserch, tfpackageserch);
        //
        Label lapriceserch = new Label("price");
        TextField tfpriceserch = new TextField();
        HBox forprice = new HBox(10);
        forprice.getChildren().addAll(lapriceserch, tfpriceserch);
        //
        Label lamsgerorr = new Label();
         //  myLabel.setFont(Font.font("Arial Rounded MT Bold", 14)); 
        lamsgerorr.setTextFill(Color.RED);
        lamsgerorr.setFont(new Font(12.0));
        lamsgerorr.setAlignment(Pos.CENTER);

        Button serch = new Button("Search");
        serch.setStyle("-fx-background-color:#657166");
        serch.setTextFill(Color.WHITE);

        //
        Button print = new Button("Print");
        print.setStyle("-fx-background-color:#657166");
        print.setTextFill(Color.WHITE);

        HBox hbutton = new HBox(220);
        hbutton.getChildren().addAll(serch, print);

        //
        Button backhome = new Button("Back to home");
        backhome.setStyle("-fx-background-color:#657166");
        backhome.setTextFill(Color.WHITE);

        page5.getChildren().addAll(hbconfirmed, fornumber, lamsgerorr, forname, fordate, forpackage, forprice, hbutton, backhome);
       

        page5.setStyle("-fx-background-color:#FEFDF1;");
      
   
         //----------------------END HOME PAGE-------------------
         
         
         
         //------------------------START PACKAGES SCENE------------
         
        Text textPackage = new Text(50,50,"Package... ");
        textPackage.setStyle("-fx-border-color: #657166 ;-fx-font: normal bold 20px 'Gabriola' ");
         
        
          //////////////////////////////////Package 1
         Text text1 = new Text(50,50, "Package 1");
         text1.setStyle("-fx-border-color: #657166 ;-fx-font: normal bold 12px 'Arial Rounded MT Bold' ");
         
         HBox hbox1 = new HBox();
        hbox1.setAlignment(Pos.CENTER);
        hbox1.setPadding(new Insets(2));
        hbox1.setStyle("-fx-border-color: #DAEBE3 ;-fx-border-width: 6px");
        
        
       Image image = new Image("file:/Users/nf/Desktop/AP1/HibernateLab/IMG_7394-removebg-preview.png"); //GRADUATION CAP
       ImageView imageView = new ImageView(image);//Setting the image view imageView.setX(50); //Setting the image positio
       imageView.setFitWidth(65);
       imageView.setFitHeight(65); //setting the fit height and width of the image view imageView.setFitWidth(200);
       imageView.setPreserveRatio(true);
       
       
        Text textc = new Text(50, 50,  "Circular cork stand, size one and a half metres.\n" +
                                         "2 transparent cake tables." +"Small cake table.\n" +
                                          "Organic balloon arch 5 meters.");
        HBox hboxc = new HBox();
        hboxc.setAlignment(Pos.CENTER);
        hboxc.setPadding(new Insets(1));  
        hboxc.setStyle("-fx-border-color: #657166 ;-fx-border-width: 3px");
       
       /////////////////////////////////
        Image image1 = new Image("https://i.pinimg.com/originals/00/0f/0e/000f0ee891d1f2baf7bccd25b0cae3de.png");
        ImageView imageView1 = new ImageView(image1);//Setting the image view imageView.setX(50); //Setting the image position
        imageView1.setFitWidth(40);
        imageView1.setFitHeight(40); //setting the fit height and width of the image view imageView.setFitWidth(200);
        imageView1.setPreserveRatio(true);
        
      
        ImageView imageView2 = new ImageView(new Image("https://i.pinimg.com/564x/90/29/f2/9029f2b345c384ac9a6214446b7e3605.jpg"));//Setting the image view imageView.setX(50); //Setting the image position
        imageView2.setFitWidth(40);
        imageView2.setFitHeight(40); //setting the fit height and width of the image view imageView.setFitWidth(200);
        imageView2.setPreserveRatio(true);
       
         Text Button = new Text(" 10-15 person  ");
        Button.setStyle("-fx-border-color: #657166 ;-fx-font: normal bold 12px 'Arial Rounded MT Bold' ");
        
        
         Label lb1 = new Label("880 SR",imageView2); 
         lb1.setContentDisplay(ContentDisplay.LEFT);
         lb1.setStyle("-fx-border-color: black; -fx-border-width: 2");
        HBox hbox2 = new HBox(20);
        hbox2.setAlignment(Pos.CENTER);
        hbox2.setPadding(new Insets(2));
        hbox2.setStyle("-fx-border-color: #657166 ;-fx-border-width: 3px");
         

      
         
      
         StackPane paneForShapes = new StackPane();
        
        
        hbox2.getChildren().addAll(imageView1,Button,imageView2,lb1);
        hbox1.getChildren().addAll(text1);
        hboxc.getChildren().addAll(imageView,textc);

       paneForShapes.getChildren().addAll(hboxc);
       
        
         
        BorderPane pane = new BorderPane();
          
          pane.setTop(hbox1); 
          pane.setBottom(hbox2);
          pane.setCenter(paneForShapes);
         // /------------------------------------
             Button.setOnMouseClicked(new EventHandler<MouseEvent>() {
           @Override
           public void handle(MouseEvent event) {
           
                  /********/
                                 
                  /********/
                  if(event.getButton()== MouseButton.SECONDARY){
                         textPackage.setText( "Package 1 selected");
                          System.out.println("trueeee");
                           Button.setFill(Color.BURLYWOOD);
                           Pprice=880;
                           PackageType="Package 1";
                          
                   
                 
                  
                  }
            
           }
       });
             
//////////////////////////////////////////////////////////-------Package 2------------------------///////////////////////////////////////////////////        
        
       Text text12 = new Text(50,50, "Package 2");
       text12.setStyle("-fx-border-color: #657166 ;-fx-font: normal bold 12px 'Arial Rounded MT Bold' ");
       
         HBox hbox12 = new HBox( );
        hbox12.setAlignment(Pos.CENTER);
        hbox12.setPadding(new Insets(2));
        hbox12.setStyle("-fx-border-color: #DAEBE3 ;-fx-border-width: 6px");
       //////////////////////////////////
       Image image2 = new Image("file:/Users/nf/Desktop/AP1/HibernateLab/IMG_7394-removebg-preview.png");
       ImageView imageView22 = new ImageView(image2);//Setting the image view imageView.setX(50); //Setting the image position
       imageView22.setFitWidth(65);
       imageView22.setFitHeight(65); //setting the fit height and width of the image view imageView.setFitWidth(200);
       imageView22.setPreserveRatio(true);
       
       
        Text textc2 = new Text(50, 50,  "Circular cork stand, size one and a half metres.\n" +
                                         "3 transparent cake tables." +"Medium cake table.\n" +
                                          "Organic balloon arch 5 meters.");
                                         
        HBox hboxc2 = new HBox();
        hboxc2.setAlignment(Pos.CENTER);
        hboxc2.setPadding(new Insets(1));  
        hboxc2.setStyle("-fx-border-color: #657166 ;-fx-border-width: 3px");
       
       /////////////////////////////////
        Image image12 = new Image("https://i.pinimg.com/originals/00/0f/0e/000f0ee891d1f2baf7bccd25b0cae3de.png");
        ImageView imageView12 = new ImageView(image12);//Setting the image view imageView.setX(50); //Setting the image position
        imageView12.setFitWidth(40);
        imageView12.setFitHeight(40); //setting the fit height and width of the image view imageView.setFitWidth(200);
        imageView12.setPreserveRatio(true);
        
      
        ImageView imageView222 = new ImageView(new Image("https://i.pinimg.com/564x/90/29/f2/9029f2b345c384ac9a6214446b7e3605.jpg"));//Setting the image view imageView.setX(50); //Setting the image position
        imageView222.setFitWidth(40);
        imageView222.setFitHeight(40); //setting the fit height and width of the image view imageView.setFitWidth(200);
        imageView222.setPreserveRatio(true);
       
         Text Button2 = new Text(" 20-25 person ");
         Button2.setStyle("-fx-border-color: #657166 ;-fx-font: normal bold 12px 'Arial Rounded MT Bold' ");
        
        
         Label lb12 = new Label("1100 SR",imageView222); 
         lb12.setContentDisplay(ContentDisplay.LEFT);
         lb12.setStyle("-fx-border-color: black; -fx-border-width: 2");
        HBox hbox22 = new HBox(20 );
        hbox22.setAlignment(Pos.CENTER);
        hbox22.setPadding(new Insets(2));
        hbox22.setStyle("-fx-border-color: #657166 ;-fx-border-width: 3px");
         

      
         
      
         StackPane paneForShapes2 = new StackPane();
       
        
        hbox22.getChildren().addAll(imageView12,Button2,imageView222,lb12);
        hbox12.getChildren().addAll(text12);
        hboxc2.getChildren().addAll(imageView22,textc2);

       paneForShapes2.getChildren().addAll(hboxc2);
       
        
         
        BorderPane pane2 = new BorderPane();
      
          pane2.setTop(hbox12); 
          pane2.setBottom(hbox22);
          pane2.setCenter(paneForShapes2);
         // /------------------------------------
             Button2.setOnMouseClicked(new EventHandler<MouseEvent>() {
           @Override
           public void handle(MouseEvent event) {
           
                
                
                  /********/
                  if(event.getButton()== MouseButton.SECONDARY){
                         textPackage.setText( "Package 2 selected");
                          System.out.println("trueeee");
                           Button2.setFill(Color.BURLYWOOD);
                           Pprice=1100;
                           PackageType="Package 2";
                           
                       
                  }
           }
       });


/////////////////////////////////////////////////////---Package 3----------------------------///////////////////////////////////////////////////       


       Text text13 = new Text(50,50, "Package 3");
       text13.setStyle("-fx-border-color: #657166 ;-fx-font: normal bold 12px 'Arial Rounded MT Bold' ");
       
         HBox hbox13 = new HBox( );
        hbox13.setAlignment(Pos.CENTER);
        hbox13.setPadding(new Insets(2));
        hbox13.setStyle("-fx-border-color: #DAEBE3 ;-fx-border-width: 6px");
       //////////////////////////////////
       Image image3 = new Image("file:/Users/nf/Desktop/AP1/HibernateLab/IMG_7394-removebg-preview.png");
       ImageView imageView3 = new ImageView(image3);//Setting the image view imageView.setX(50); //Setting the image position
       imageView3.setFitWidth(65);
       imageView3.setFitHeight(65); //setting the fit height and width of the image view imageView.setFitWidth(200);
       imageView3.setPreserveRatio(true);
       
       
        Text textc3 = new Text(50, 50,  "Circular cork stand, size one and a half metres.\n" +
                                        "4 transparent cake tables." +"Big cake table.\n" +
                                         "Organic balloon arch 5 meters.");
                                         
        HBox hboxc3 = new HBox();
        hboxc3.setAlignment(Pos.CENTER);
        hboxc3.setPadding(new Insets(1));  
        hboxc3.setStyle("-fx-border-color: #657166 ;-fx-border-width: 3px");
       
       /////////////////////////////////
        Image image13 = new Image("https://i.pinimg.com/originals/00/0f/0e/000f0ee891d1f2baf7bccd25b0cae3de.png");
        ImageView imageView13 = new ImageView(image13);//Setting the image view imageView.setX(50); //Setting the image position
        imageView13.setFitWidth(40);
        imageView13.setFitHeight(40); //setting the fit height and width of the image view imageView.setFitWidth(200);
        imageView13.setPreserveRatio(true);
        
      
        ImageView imageView233 = new ImageView(new Image("https://i.pinimg.com/564x/90/29/f2/9029f2b345c384ac9a6214446b7e3605.jpg"));//Setting the image view imageView.setX(50); //Setting the image position
        imageView233.setFitWidth(40);
        imageView233.setFitHeight(40); //setting the fit height and width of the image view imageView.setFitWidth(200);
        imageView233.setPreserveRatio(true);
       
         Text Button3 = new Text(" 30-35 person ");
         Button3.setStyle("-fx-border-color: #657166 ;-fx-font: normal bold 12px 'Arial Rounded MT Bold' ");
        
    
         Label lb13 = new Label("1500 SR",imageView233); 
         lb13.setContentDisplay(ContentDisplay.LEFT);
         lb13.setStyle("-fx-border-color: black; -fx-border-width: 2");
        HBox hbox23 = new HBox(20);
        hbox23.setAlignment(Pos.CENTER);
        hbox23.setPadding(new Insets(2));
        hbox23.setStyle("-fx-border-color: #657166 ;-fx-border-width: 3px");
         

      
         
      
         StackPane paneForShapes3 = new StackPane();
        
        
        hbox23.getChildren().addAll(imageView13,Button3,imageView233,lb13);
        hbox13.getChildren().addAll(text13);
        hboxc3.getChildren().addAll(imageView3,textc3);

       paneForShapes3.getChildren().addAll(hboxc3);
       
        
         
        BorderPane pane3 = new BorderPane();
      
          pane3.setTop(hbox13); 
          pane3.setBottom(hbox23);
          pane3.setCenter(paneForShapes3);
         // /------------------------------------
             Button3.setOnMouseClicked(new EventHandler<MouseEvent>() {
           @Override
           public void handle(MouseEvent event) {
           
                  
           
                  /********/
                  if(event.getButton()== MouseButton.SECONDARY){
                         textPackage.setText( "Package 3 selected");
                          System.out.println("trueeee");
                           Button3.setFill(Color.BURLYWOOD);
                           Pprice=1500;
                           PackageType="Package 3";
                           
                         
                  }
           }
       });




///////////////////////++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++////////////////////////////////////////////////
           
     Text ButtonNext = new Text("     Next     ");
      Image imageButtonNext  = new Image("file:/Users/nf/Desktop/AP1/HibernateLab/IMG_2838-removebg-preview.png");
       ImageView imageViewButtonNext  = new ImageView(imageButtonNext );//Setting the image view imageView.setX(50); //Setting the image position
       imageViewButtonNext .setFitWidth(25);
       imageViewButtonNext.setFitHeight(25); //setting the fit height and width of the image view imageView.setFitWidth(200);
       imageViewButtonNext .setPreserveRatio(true);
       
          HBox buttonNext = new HBox(10);
        buttonNext.setAlignment(Pos.CENTER);
        buttonNext.getChildren().addAll(ButtonNext,imageViewButtonNext);
        
       
 
 
       Text ButtonBack = new Text("     Back     ");
       Text topText = new Text("     Packages     ");
       topText.setStyle("-fx-border-color: #657166 ;-fx-font: normal bold 16px 'MV Boli' ");
       
        Image imageButtonBack  = new Image("file:/Users/nf/Desktop/AP1/HibernateLab/IMG_1365-removebg-preview.png");
       ImageView imageViewButtonBack  = new ImageView(imageButtonBack );//Setting the image view imageView.setX(50); //Setting the image position
       imageViewButtonBack .setFitWidth(25);
       imageViewButtonBack .setFitHeight(25); //setting the fit height and width of the image view imageView.setFitWidth(200);
       imageViewButtonBack .setPreserveRatio(true);
      
       HBox buttonBack = new HBox(4);
        buttonBack.setAlignment(Pos.CENTER);
        
       
        
   
       buttonBack.getChildren().addAll(imageViewButtonBack,ButtonBack,topText,textPackage);

  
      

////////////////////////////////////////////////////////////////////////////////====================////////////////////////

             VBox finalPackage =new VBox(5);
             finalPackage.getChildren().addAll(pane,pane2,pane3);
             finalPackage.setPadding(new Insets(10,10,10,10));
            BorderPane panef = new BorderPane();
            panef.setStyle("-fx-background-color: #FEFDF1 ");
          
           
            panef.setTop(buttonBack);
            panef.setCenter(finalPackage);
            panef.setBottom(buttonNext);
            
            
         //-------------------END PACKAGES SCENE---------------------------------
         
         
      
        //---------------------------START EXTRA SCENE----------------------
        //colors
        Color SceneColor = Color.web("0xF5F5DC",1.0);
        Color Green = Color.web("0x657166",1.0);
        Color Pink = Color.web("0xF3C3B2",1.0);
        //Page header text
        Text ExtraText= new Text ("Extra services");
        ExtraText.setFont(Font.font("Arial Rounded MT Bold", FontWeight.BOLD, FontPosture.REGULAR, 30));
        ExtraText.setFill(Green);
        
        //back button
        Button Extraback= new Button("Back");
        Extraback.setStyle("-fx-background-color:#657166");
        Extraback.setTextFill(Color.WHITE);
        //page header HBox
        
        HBox headerpane = new HBox(10);
        headerpane.getChildren().addAll(Extraback,ExtraText);
       
        Extraback.setAlignment(Pos.BOTTOM_LEFT);
        //decorations text
        Text DecorationsText=new Text ("Decorations");
        DecorationsText.setFont(Font.font("Gabriola", FontWeight.BOLD, FontPosture.REGULAR, 20));
        DecorationsText.setFill(Pink);
        
       
        //radio buttons for decorations
        RadioButton RB_GoldWhite=new RadioButton("Gold & White");
        RadioButton RB_BlackSilver=new RadioButton("Black & Silver");
        RadioButton RB_PinkWhite=new RadioButton("Pink & White");
        
        
        ToggleGroup group = new ToggleGroup();
        RB_GoldWhite.setToggleGroup(group);
        RB_BlackSilver.setToggleGroup(group);
        RB_PinkWhite.setToggleGroup(group);
        
        //vbox for decorations : header & radio buttons
        VBox DecoratoinButtonsPane = new VBox(5);
        DecoratoinButtonsPane.getChildren().addAll( DecorationsText,RB_GoldWhite,RB_BlackSilver,RB_PinkWhite);
        DecoratoinButtonsPane.setAlignment(Pos.TOP_LEFT);
        
        //notes text
        Text NotesText = new Text("Please add your notes or any particular theme you would like for\n your party");
        NotesText.setFont(Font.font("MV Boli", FontWeight.BOLD, FontPosture.REGULAR, 10));
        NotesText.setFill(Color.BLACK);
        
        //notes text field
        TextField Notes = new TextField();
        Notes.setEditable(true);
        Notes.setMaxWidth(300);
       //vbox for notes : description & textfield
        VBox NotesPane = new VBox(5);
        NotesPane.getChildren().addAll(NotesText,Notes);
        NotesPane.setPadding(new Insets(20));
        
        //header for food makers
        Text FoodMakersText=new Text ("Party food makers");
        FoodMakersText.setFont(Font.font("Gabriola", FontWeight.BOLD, FontPosture.REGULAR, 20));
        FoodMakersText.setFill(Pink);
        
        //checkBoxes for food makers
         CheckBox popcorn= new CheckBox("Popcorn        100 SAR");
         CheckBox icecream= new CheckBox("Icecream       150 SAR");
         CheckBox pancakes= new CheckBox("Pancakes       95 SAR");
         CheckBox candyfloss= new CheckBox("Candy Floss   90 SAR");
         CheckBox waffles= new CheckBox("Waffles         70 SAR");
         
        
         //vbox for food makers
        VBox FoodMakersPane = new VBox(5);
        FoodMakersPane.getChildren().addAll(FoodMakersText,popcorn,icecream,pancakes,candyfloss,waffles);
        
        
        //next button HBox
        HBox nextPane = new HBox();
        Button next = new Button("Next");
        next.setStyle("-fx-background-color:#657166");
        next.setTextFill(Color.WHITE);
        next.setAlignment(Pos.BOTTOM_RIGHT);
        nextPane.getChildren().add(next);
        
     
        
        //price Lable pane
        VBox pricePane = new VBox(20);
        pricePane.getChildren().addAll(PriceLabel);
        priceDisplay.setEditable(false);
        priceDisplay.setMaxWidth(70);
       PriceLabel.setContentDisplay(ContentDisplay.BOTTOM);
        
        //root VBox
        VBox ExtraSceneRoot=new VBox(5);
        ExtraSceneRoot.setPadding(new Insets(20));
        ExtraSceneRoot.getChildren().addAll(headerpane,DecoratoinButtonsPane,NotesPane,FoodMakersPane, pricePane,nextPane);
        ExtraSceneRoot.setStyle(STYLESHEET_MODENA);
        ExtraSceneRoot.setStyle("-fx-background-color:#FEFDF1;");
        nextPane.setAlignment(Pos.BOTTOM_RIGHT);
        nextPane.setPadding(new Insets(0,20,0,0));
        
       
        //lists to store information about the food makers
       List<CheckBox> checkboxes = new ArrayList<>();
       List<Integer> checkboxPrices = new ArrayList<>();

        //checkboxes and prices
        checkboxes.add(popcorn);
        checkboxPrices.add(100);

        checkboxes.add(icecream);
        checkboxPrices.add(150);

        checkboxes.add(pancakes);
        checkboxPrices.add(95);

        checkboxes.add(waffles);
        checkboxPrices.add(70);

        checkboxes.add(candyfloss);
        checkboxPrices.add(90);

   // Update total price based on checkbox selection 
    for (int i = 0; i < checkboxes.size(); i++) {
    CheckBox checkbox = checkboxes.get(i);
    int currentPrice = checkboxPrices.get(i);
    
    checkbox.setOnAction(e ->{ handleCheckboxAction(checkbox, currentPrice);
    
    });
}
    
    
  //------------------END EXTRA SCENE-----------------------------------
       
  
  
  
  //--------------------------LOG IN SCENE-----------------
  
  
  
     BorderPane paneforAll =new BorderPane();
        
      // This a GridPane for the Text and TextField in the CustomerScene
        GridPane  ForTextField= new GridPane();
        ForTextField.setHgap(21);
        ForTextField.setVgap(15);   
      
     
        // Text for LogIn ( the family of the font is Arial Rounded MT Bold , and size 20 , and color F3C3B2)
        Text login = new Text("Login:"); //Creating a Text object 
        login.setFont(Font.font("Arial Rounded MT Bold", FontWeight.BOLD, FontPosture.REGULAR, 20));
        Color textColor = Color.web("F3C3B2",1.0);
        login.setFill(textColor);
        ForTextField.add(login,1,1);
     

        // First Rectangle 
        Rectangle rectangle = new Rectangle();
        //Setting the Properties of the Rectangle 
        rectangle.setX(80); 
        rectangle.setY(45);
        rectangle.setWidth(280);
        rectangle.setHeight(130);
        // For rectangle color 
        Color colorforRectangle = Color.web("DAEBE3",1.0);
        rectangle.setFill(colorforRectangle);
        Color colorforRs = Color.web("657166",1.0);
        rectangle.setStroke(colorforRs);
        
        // TextField for the customer Phone number
        TextField Phone=new TextField();
        Phone.setPromptText(" Enter the Phone number");
        ForTextField.add(Phone,2,2);
       
       
        // TextField for the customer Name
        TextField Name=new TextField();
        Name.setPromptText(" Enter your Name ");
        ForTextField.add(Name,2,3);
        
      
       DatePicker datePicker=new DatePicker();
       ForTextField.add(datePicker,2,4);
  
      
        
        // Text for Credit Card ( the family of the font is Arial Rounded MT Bold , and size 20 , and color F3C3B2)
        Text creditcard = new Text("Credit Card:"); //Creating a Text object 
        creditcard.setFont(Font.font("Arial Rounded MT Bold", FontWeight.BOLD, FontPosture.REGULAR, 20));
        creditcard.setFill(textColor);
        ForTextField.add(creditcard,1,6);

        // second rectangle 
        Rectangle rectangle2 = new Rectangle();
        //Setting the Properties of the Rectangle 
        rectangle2.setX(80); 
        rectangle2.setY(220);
        rectangle2.setWidth(280);
        rectangle2.setHeight(170);
        // For rectangle color
        rectangle2.setFill(colorforRectangle);
        rectangle2.setStroke(colorforRs);
      
        
   
       //TextField for the customer Cardholder Name 
        TextField CardholderName=new TextField();
        CardholderName.setPromptText(" Enter the Cardholder Name ");
        ForTextField.add(CardholderName,2,7);
       
        
       //TextField for the customer Card number 
        TextField CardNumber=new TextField();
        CardNumber.setPromptText(" Enter your Card number ");
        ForTextField.add(CardNumber,2,8);
    
        
    
       //TextField for the customer MM/YY 
       TextField MM_YY=new TextField();
       MM_YY.setPrefWidth(40);
       MM_YY.setPromptText(" MM/YY ");
       ForTextField.add(MM_YY,2,9);
       
       //TextField for the customer CVC  
       TextField CVC=new TextField();
       CVC.setPrefWidth(40);
       CVC.setPromptText(" CVC ");
       ForTextField.add(CVC,2,10);

       
       // HBox to put the verify Button on it , we want this button to be in the bottom of the BorderPane
       HBox verify=new HBox();
       
       Button verify1= new Button("Verify");
       verify1.setStyle("-fx-background-color:#657166;"); 
       verify1.setTextFill(Color.WHITE);
       
       verify.setPadding(new Insets(10,10, 10, 10)); 
       verify.setAlignment(Pos.CENTER);
       verify.getChildren().addAll(verify1);
       
       
       // HBox to put the Back Button on it , we want this button to be in the top of the BorderPane
       HBox top=new HBox();
       
       Button back= new Button("back");

       back.setStyle("-fx-background-color:#657166;"); 
       back.setTextFill(Color.WHITE);
       
       top.setPadding(new Insets(10,0,5,10)); 
       top.getChildren().addAll(back);
       
       // This Pane to put the rectangle with GridPane for the TextField
       Pane center=new Pane();
       center.getChildren().addAll(rectangle,rectangle2,ForTextField);
      
         // to set all the CustomerScene in the BorderPane
         paneforAll.setBottom(verify);
         paneforAll.setCenter(center);
         paneforAll.setTop(top);
         paneforAll.setStyle("-fx-background-color:#FEFDF1;");
         
         
         
         //The Verify  Scene -----------------------------------------------------------------------------------------
         

      Random random = new Random();
      int randomNumber=1000 + random.nextInt(9000);
        Text verifyCode = new Text( " You're order are completed  "); 
        verifyCode.setFont(Font.font("Arial Rounded MT Bold", FontWeight.BOLD, FontPosture.REGULAR, 18));
        verifyCode.setFill(textColor);

      Text randomtext = new Text( " You're order Number are: \n  "); 
        randomtext.setFont(Font.font("Arial Rounded MT Bold", FontWeight.BOLD, FontPosture.REGULAR, 18));
        randomtext.setFill(textColor); 
        
         Text randomnum= new Text(""+randomNumber ); 
        randomnum.setFill(textColor); 
        
        Button back1= new Button("back to home");
         back1.setStyle("-fx-background-color:#657166;"); 
         back1.setTextFill(Color.WHITE);


      StackPane paneforAll1 = new StackPane();
    
      paneforAll1.setStyle("-fx-background-color:#FEFDF1;");
      paneforAll1.setAlignment(Pos.CENTER);
      Canvas canvas = new Canvas(800, 600);
      paneforAll1.getChildren().add(canvas);

       
     VBox layout = new VBox();
     layout.setPadding(new Insets(30,10,30,10));
     Label label = new Label("");
     layout.setAlignment(Pos.CENTER);
     layout.getChildren().addAll(verifyCode, randomtext,randomnum,label,  back1); // Adding a spacer between label and button

    
      
        paneforAll1.getChildren().add(layout);
         
        // Start the fireworks animation at the top of the scene
       startFireworksAnimation(canvas.getGraphicsContext2D(), 400, 0);
        
    
     // VerifyScene 
       Scene VerifyScene  = new Scene(paneforAll1, 390, 500);
   

        verify1.setOnAction(e->{ if (Name.getText().equals("")&& datePicker.valueProperty().equals("")&& CardholderName.getText().equals("") && !Phone.getText().matches("05\\d{8}") && !CardNumber.getText().matches("^[0-9]+$") && !MM_YY.getText().matches("\\d{2}/\\d{2}")&& !CVC.getText().matches("\\d{3}")) {
                  Name.clear();
                  Phone.clear();
                  CardholderName.clear();
                  CardNumber.clear();
                  MM_YY.clear();
                  CVC.clear();
                  
                  Phone.setPromptText(" Enter the Phone number");
                  Name.setPromptText(" Enter your Name ");
                  datePicker.setPromptText(" Enter the Date");
                  CardholderName.setPromptText(" Enter the Cardholder Name ");
                  CardNumber.setPromptText(" Enter your Card number ");
                  MM_YY.setPromptText(" MM/YY ");
                  CVC.setPromptText(" CVC "); 
            } else if (!Phone.getText().matches("05\\d{8}")) {
                Phone.clear();
                Phone.setPromptText(" the number that start with 05 ");
                
            } else if (Name.getText().equals("")) {
                 Name.clear();
              Name.setPromptText(" Enter your Name ");
           } 
             else if (CardholderName.getText().equals("")) {
                  CardholderName.clear();
              CardholderName.setPromptText(" Enter the Cardholder Name ");
           } 
         else if (!CardNumber.getText().matches("^[0-9]+$")) {
              CardNumber.clear();
              CardNumber.setPromptText(" Enter your Card number ");
           } 
         else if (!MM_YY.getText().matches("\\d{2}/\\d{2}")) {
              MM_YY.clear();
             MM_YY.setPromptText(" MM/YY ");
           } 
         else if (!CVC.getText().matches("\\d{3}")) {
              CVC.clear();
              CVC.setPromptText(" CVC ");
           } 
         else if ( datePicker.valueProperty().equals("")) {
             datePicker.setPromptText(" Enter the date ");

           } 
        
else {
             
 
             order.setOrderNumber(randomNumber);
             order.setTotalPrice(total);
             order.setPackageType(PackageType);
             order.setDate(datePicker.getValue().toString());
             
             
             
            Customer st1 = new Customer(); 
       st1.setPhoneNumber(Integer.parseInt(Phone.getText()));
        st1.setName( Name.getText()); 
        
        
        //insert new Customer and Order
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        int sId2 = (Integer) session.save(order);session.save(st1);
         tx.commit();
         session.close();
          System.out.println(order.getOrderNumber()+" "+st1.getPhoneNumber());
          
     
             
        stage.setScene(VerifyScene);
            }
        });
        
       
  //-----------------------------------------------
  
  
  //------------------------CART SCENE------------------
  GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(30);
        grid.setHgap(5);

        Label LenterOrdernum = new Label("Enter your order number:");
        TextField ENorderField = new TextField();
        grid.add(LenterOrdernum, 0, 0);
        grid.add(ENorderField, 1, 0);
        
        
        
        
        
     Label massegeerror = new Label();
      grid.add(massegeerror, 1, 2);
                massegeerror.setFont(Font.font("MV Boli", 10));
        massegeerror.setTextFill(Color.RED);
//        massegeerror.setText("");
//massegeerror.setVisible(false);

//         Label orderLabetwo = new Label("Order Number:");
       
        Label phonLabel = new Label("Enter your Phone Number:");
        TextField phonField = new TextField();
        grid.add(phonLabel, 0, 1);
        grid.add(phonField, 1, 1);
        
        
        Label orderLabel = new Label("order Number:");
        TextField orderField = new TextField();
        grid.add(orderLabel, 0, 3);
        grid.add(orderField, 1, 3);

      

        Label packageLabel = new Label("Package Type:");
        TextField packageField = new TextField();
        grid.add(packageLabel, 0, 4);
        grid.add(packageField, 1, 4);
        
      Label nameLabel = new Label("Name:");
        TextField nameDisplay = new TextField();
        grid.add(nameLabel, 0, 5);
        grid.add(nameDisplay, 1, 5);
        
        Label dateLabel = new Label("Date:");
        TextField priceDisplay = new TextField();
        grid.add(dateLabel, 0, 6);
        grid.add(priceDisplay, 1, 6);

        Label priceLabel = new Label("Price");
        TextField priceField = new TextField();
        grid.add(priceLabel, 0, 7);
        grid.add(priceField, 1, 7);
        
      

        //back to home button
        Button backButton = new Button("Back to home");
        grid.add(backButton, 1, 8);
        backButton.setStyle("-fx-background-color:#657166");
        backButton.setTextFill(Color.WHITE);

      
        
        //new scene
       
        Scene WelcomeScene = new Scene(page1, 390, 500);//WELCOME SCENE
        Scene scene = new Scene(panef,390,500);//PACKAGE SCENE
        Scene ExtraScene = new Scene(ExtraSceneRoot, 390, 500);//EXTRA SCENE
        Scene CustomerScene  = new Scene(paneforAll, 390, 500);//LOG IN PAGE
        Scene cartScene = new Scene(grid, 390, 500);//CART PAGE
        grid.setStyle("-fx-background-color:#FEFDF1;");
        stage.setScene(WelcomeScene);
        stage.show();
        
       
        //ACTIONS TO MOVE BETWEEN THE SCENES
   
       btpackges.setOnAction(e -> {stage.setScene(scene);
       stage.setScene(scene);
      });
       
        //cart button to display reciept
        btcart.setOnAction(e ->{
            stage.setScene(cartScene);
        });
        
        // printButton.setOnAction(e -> {);});
        
        //back to home from cart
        backButton.setOnAction(e -> {
            stage.setScene(WelcomeScene);
        });
        



            
       
            phonField.setOnKeyPressed(e -> {
            if(e.getCode()== KeyCode.ENTER){
            if (ENorderField.getText().equals("") ) {
                massegeerror.setText("Enter order number");
            } else if (!ENorderField.getText().matches("^[0-9]+$")) {
                massegeerror.setText(" The order numder must \nbe digit only ");
            
            
            } else if (phonField.getText().equals("")) {
                  massegeerror.setText("Enter order number");
            
            
            } else if (!phonField.getText().matches("05\\d{8}")) {
                massegeerror.setText(" The Phone numder must start with 05  ");
            
            
            } 
            
            else{
                
                 Session   session = HibernateUtil.getSessionFactory().openSession(); 
                 Transaction  tx = session.beginTransaction(); 
           

                int SearchKey = Integer.parseInt(ENorderField.getText());
                orderField.textProperty().bind(ENorderField.textProperty());

                Neworder OrderSearch = null;
                OrderSearch = (Neworder) session.get(Neworder.class, SearchKey);
                
                //  ********retireve Customer name***********
                 int SearchKey1 = Integer.parseInt(phonField.getText());
                
                Customer CustomerSearch = null;
                CustomerSearch = (Customer) session.get(Customer.class, SearchKey1);
                
                String StrName = CustomerSearch.getName();
                nameDisplay.setText(StrName);
                
                //  ********retireve Package***********
                String StrPackageType = OrderSearch.getPackageType();
                packageField.setText(StrPackageType);

                //  ********retireve date***********
               String StrDate = OrderSearch.getDate();
               priceDisplay.setText(StrDate);
            
               //retireve total price
               String StrPrice = String.valueOf(OrderSearch.getTotalPrice());
               priceField.setText(StrPrice);
               
               
            }
            }

        });
            
            

        //Button back from packages to home page
        ButtonBack.setOnMouseEntered(e ->{
      
        stage.setScene(WelcomeScene);
       
       ButtonBack.setFill(Color.BURLYWOOD);
 });
        
        
        //button next to extra page
         ButtonNext.setOnMouseEntered(e ->{ 
       
         stage.setScene(ExtraScene);
       
         ButtonNext.setFill(Color.BURLYWOOD);
           
        });
         
         //button next to log in
         next.setOnAction(e->{ 
             stage.setScene(CustomerScene);
             
         });
         
         // Back from Extra to Package Page
         Extraback.setOnAction(e->{
             stage.setScene(scene);
             
         });
         
         //back from log in to welcome page
           back1.setOnAction(e-> { 
           stage.setScene(WelcomeScene);

        });
           
           //back from log in to extrapage
           back.setOnAction(e ->{
               stage.setScene(ExtraScene);
           });
           
           
           
    }
    
    
    
     public static void main(String[] args) {
        launch();
    }
 private void startFireworksAnimation(GraphicsContext gc, double startX, double startY) {
        List<Firework> fireworks = new ArrayList<>();
        Random random = new Random();

        AnimationTimer animationTimer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                // Clear the canvas
                gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());

                // Update and draw each firework
                Iterator<Firework> iterator = fireworks.iterator();
                while (iterator.hasNext()) {
                    Firework firework = iterator.next();
                    firework.update();
                    firework.draw(gc);

                    // Remove fireworks that have finished
                    if (firework.isFinished()) {
                        iterator.remove();
                    }
                }

                // Add new fireworks at random intervals
                if (random.nextDouble() < 0.02) {
                    fireworks.add(new Firework(gc, startX + random.nextInt(100) - 50, startY));
                }
            }
        };

        // Start the animation timer
        animationTimer.start();
    }

    // Firework class represents an individual firework particle
    private static class Firework {
        private static final int PARTICLE_COUNT = 300;
        private static final double GRAVITY = 0.1;

        private final GraphicsContext gc;
        private final Particle[] particles;
        private boolean finished;

        public Firework(GraphicsContext gc, double startX, double startY) {
            this.gc = gc;
            this.particles = new Particle[PARTICLE_COUNT];

            for (int i = 0; i < PARTICLE_COUNT; i++) {
                particles[i] = new Particle(startX, startY);
            }
        }

        public void update() {
            for (Particle particle : particles) {
                particle.update();
            }

            // Check if all particles have gone below the canvas
            finished = particles[0].getY() > gc.getCanvas().getHeight();
        }

        public void draw(GraphicsContext gc) {
            for (Particle particle : particles) {
                particle.draw(gc);
            }
        }

        public boolean isFinished() {
            return finished;
        }
    }

    // Particle class represents an individual particle in a firework
    private static class Particle {
        private double x;
        private double y;
        private double xSpeed;
        private double ySpeed;
        private Color color;

        public Particle(double x, double y) {
            this.x = x;
            this.y = y;
            this.xSpeed = Math.random() * 5 - 2.5;
            this.ySpeed = Math.random() * 5 - 2.5;
            this.color = Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256));
        }

        public void update() {
            x += xSpeed;
            y += ySpeed;
            ySpeed += Firework.GRAVITY;
        }

        public void draw(GraphicsContext gc) {
            gc.setFill(color);
            gc.fillOval(x, y, 5, 5);
        }

        public double getX() {
            return x;
        }

        public double getY() {
            return y;
        }
    }
}